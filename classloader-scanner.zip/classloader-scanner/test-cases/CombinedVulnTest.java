import javax.naming.InitialContext;

public class CombinedVulnTest {
    public static void main(String[] args) throws Exception {
        System.out.println("=== Combined Vulnerability Test ===");
        
        // This should trigger STATIC analysis detection
        String className = args.length > 0 ? args[0] : "java.lang.Runtime";
        Class.forName(className);  // Static: Insecure Reflection
        
        // This should trigger DYNAMIC analysis detection
        InitialContext ctx = new InitialContext();  // Dynamic: JNDI Injection
        
        System.out.println("Combined test completed - both static and dynamic vulnerabilities present!");
    }
}
