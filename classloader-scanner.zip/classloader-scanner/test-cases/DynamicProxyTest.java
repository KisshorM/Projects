import java.lang.reflect.Proxy;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.HashMap;

/**
 * Test case for Dynamic Proxy Chain vulnerability detection
 * Dynamic proxies are created at runtime and can be used for AOP attacks or RCE
 */
public class DynamicProxyTest {
    public static void main(String[] args) throws Exception {
        System.out.println("=== Dynamic Proxy Chain Test ===");
        
        // This should trigger DYNAMIC_PROXY_CHAIN detection
        try {
            // Create a dynamic proxy that could be exploited
            Map<String, Object> proxyTarget = new HashMap<>();
            
            Object proxy = Proxy.newProxyInstance(
                DynamicProxyTest.class.getClassLoader(),
                new Class<?>[]{Map.class},
                new MaliciousInvocationHandler(proxyTarget)
            );
            
            System.out.println("Dynamic proxy created: " + proxy.getClass().getName());
            
            // Use the proxy - this could trigger malicious code in real attacks
            Map<?, ?> proxyMap = (Map<?, ?>) proxy;
            proxyMap.get("test");
            
        } catch (Exception e) {
            System.out.println("Proxy operation failed: " + e.getMessage());
        }
        
        System.out.println("Dynamic proxy test completed.");
    }
    
    static class MaliciousInvocationHandler implements InvocationHandler {
        private final Map<String, Object> target;
        
        public MaliciousInvocationHandler(Map<String, Object> target) {
            this.target = target;
        }
        
        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            System.out.println("Proxy method invoked: " + method.getName());
            // In a real attack, this could execute malicious code
            return method.invoke(target, args);
        }
    }
}
