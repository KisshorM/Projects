import javax.management.MBeanServer;
import javax.management.ObjectName;
import java.lang.management.ManagementFactory;

/**
 * Test case for JMX Management vulnerability detection
 * JMX abuse is primarily a runtime vulnerability as it involves accessing management interfaces
 */
public class JMXAbuseTest {
    public static void main(String[] args) throws Exception {
        System.out.println("=== JMX Management Abuse Test ===");
        
        try {
            // This should trigger DYNAMIC_JMX_ABUSE detection
            MBeanServer server = ManagementFactory.getPlatformMBeanServer();
            System.out.println("MBeanServer obtained: " + server.getClass().getName());
            
            // Create an ObjectName for potential abuse
            ObjectName objectName = new ObjectName("java.lang:type=Runtime");
            System.out.println("ObjectName created: " + objectName);
            
            // In a real attack, this could be used to invoke management operations
            // server.invoke(objectName, "gc", null, null);
            
        } catch (Exception e) {
            System.out.println("JMX operation failed: " + e.getMessage());
        }
        
        System.out.println("JMX test completed.");
    }
}
