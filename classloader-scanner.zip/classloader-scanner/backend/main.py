from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Union
import subprocess, tempfile, os, shutil, platform, json, zipfile, re

app = FastAPI()

class Finding(BaseModel):
    line: int
    type: str
    description: str
    code: str
    sanitized_code: str

class AnalysisResult(BaseModel):
    findings: List[Finding]
    sanitized_file: str

class ErrorResponse(BaseModel):
    error: str

def get_java_paths():
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(backend_dir)
    analyzer_dir = os.path.join(project_root, "analyzer")
    jar_path = os.path.join(analyzer_dir, "javaparser-core-3.26.4.jar")
    agent_jar_path = os.path.join(project_root, "agent", "simple-classloader-agent.jar")
    separator = ";" if platform.system() == "Windows" else ":"
    return analyzer_dir, jar_path, agent_jar_path, separator

def extract_json_from_output(output: str):
    try:
        first = output.find("{")
        last = output.rfind("}")
        if first == -1 or last == -1:
            return None
        return json.loads(output[first:last + 1])
    except Exception:
        return None

@app.post("/analyze", response_model=Union[AnalysisResult, ErrorResponse])
async def analyze(file: UploadFile = File(...)):
    try:
        content = await file.read()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".java", mode='w', encoding='utf-8') as tmp:
            tmp.write(content.decode('utf-8'))
            tmp_path = tmp.name 


        analyzer_dir, jar_path, agent_jar_path, sep = get_java_paths()
        java_cmd = [
            "java", "-cp", f"{analyzer_dir}{sep}{jar_path}", "Analyzer", tmp_path
        ]
        result = subprocess.run(java_cmd, capture_output=True, text=True, timeout=15)
        print("=== Analyzer stdout ===")
        print(result.stdout)
        print("=== Analyzer stderr ===")
        print(result.stderr)
        os.unlink(tmp_path)

        if result.returncode != 0:
            raise HTTPException(status_code=400, detail="Java analyzer failed.")

        parsed = extract_json_from_output(result.stdout)
        if not parsed:
            raise HTTPException(status_code=500, detail="Could not parse analyzer output.")

        return AnalysisResult(
            findings=[Finding(**f) for f in parsed.get("findings", [])],
            sanitized_file=parsed.get("sanitized_file", "").replace("\\n", "\n")
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/analyze_dynamic", response_model=dict)
async def analyze_dynamic(file: UploadFile = File(...), user_input: str = Form("")):
    """
    Analyze Java code with dynamic classloader vulnerability detection using our agent
    """
    try:
        content = await file.read()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".java", mode='w', encoding='utf-8') as tmp:
            tmp.write(content.decode('utf-8'))
            tmp_path = tmp.name 

        analyzer_dir, jar_path, agent_jar_path, sep = get_java_paths()
        
        # First run static analysis
        static_result = subprocess.run(
            ["java", "-cp", f"{analyzer_dir}{sep}{jar_path}", "Analyzer", tmp_path],
            capture_output=True, text=True, timeout=15
        )
        
        static_findings = []
        if static_result.returncode == 0:
            parsed_static = extract_json_from_output(static_result.stdout)
            if parsed_static:
                static_findings = parsed_static.get("findings", [])

        # Extract class name for compilation
        import re
        class_match = re.search(r'public\s+class\s+([A-Za-z0-9_]+)', content.decode('utf-8'))
        class_name = class_match.group(1) if class_match else "Main"
        
        # Create temporary directory for dynamic analysis
        temp_dir = tempfile.mkdtemp()
        java_file = os.path.join(temp_dir, f"{class_name}.java")
        
        with open(java_file, 'w', encoding='utf-8') as f:
            f.write(content.decode('utf-8'))
        
        # Compile the Java file
        compile_proc = subprocess.run(
            ["javac", f"{class_name}.java"],
            cwd=temp_dir, capture_output=True, text=True, timeout=10
        )
        
        if compile_proc.returncode != 0:
            os.unlink(tmp_path)
            shutil.rmtree(temp_dir)
            return {
                "error": f"Compilation failed: {compile_proc.stderr}",
                "static_findings": static_findings,
                "dynamic_logs": [],
                "compile_error": compile_proc.stderr
            }
        
        # Run with dynamic agent
        exec_proc = subprocess.run(
            ["java", f"-javaagent:{agent_jar_path}", class_name],
            cwd=temp_dir,
            input=user_input,
            capture_output=True, text=True, timeout=10
        )
        
        # Extract security logs from agent
        dynamic_logs = []
        for line in exec_proc.stdout.splitlines() + exec_proc.stderr.splitlines():
            if "[SECURITY LOG][AGENT]" in line:
                dynamic_logs.append(line.strip())
        
        # Clean up
        os.unlink(tmp_path)
        shutil.rmtree(temp_dir)
        
        return {
            "static_findings": static_findings,
            "dynamic_logs": dynamic_logs,
            "program_output": exec_proc.stdout,
            "program_errors": exec_proc.stderr,
            "compile_error": compile_proc.stderr if compile_proc.returncode != 0 else "",
            "execution_success": exec_proc.returncode == 0,
            "has_static_findings": len(static_findings) > 0,
            "has_dynamic_logs": len(dynamic_logs) > 0
        }
        
    except subprocess.TimeoutExpired:
        if 'tmp_path' in locals():
            os.unlink(tmp_path)
        if 'temp_dir' in locals():
            shutil.rmtree(temp_dir)
        raise HTTPException(status_code=408, detail="Execution timed out.")
    except Exception as e:
        if 'tmp_path' in locals():
            os.unlink(tmp_path)
        if 'temp_dir' in locals():
            shutil.rmtree(temp_dir)
        raise HTTPException(status_code=500, detail=str(e))

# ... analyze_zip and analyze_code unchanged ...

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
