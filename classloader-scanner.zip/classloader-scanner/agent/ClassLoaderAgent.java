import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.implementation.MethodDelegation;
import net.bytebuddy.implementation.bind.annotation.*;
import net.bytebuddy.matcher.ElementMatchers;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.concurrent.Callable;

/**
 * Java Agent for dynamically detecting classloader vulnerabilities using Byte Buddy
 */
public class ClassLoaderAgent {
    
    public static void premain(String agentArgs, Instrumentation inst) {
        System.out.println("[CLASSLOADER-AGENT] Starting dynamic classloader vulnerability detection");
        
        try {
            // Install interceptors for various classloader operations
            new AgentBuilder.Default()
                .type(ElementMatchers.named("java.lang.Class"))
                .transform((builder, type, classLoader, module) ->
                    builder.method(ElementMatchers.named("forName"))
                        .intercept(MethodDelegation.to(Interceptor.class)))
                        
                .type(ElementMatchers.isSubTypeOf(ClassLoader.class))
                .transform((builder, type, classLoader, module) ->
                    builder.method(ElementMatchers.named("loadClass"))
                        .intercept(MethodDelegation.to(Interceptor.class)))
                        
                .type(ElementMatchers.isSubTypeOf(ClassLoader.class))
                .transform((builder, type, classLoader, module) ->
                    builder.method(ElementMatchers.named("defineClass"))
                        .intercept(MethodDelegation.to(Interceptor.class)))
                        
                .installOn(inst);
                
            System.out.println("[CLASSLOADER-AGENT] Agent installed successfully");
            
        } catch (Exception e) {
            System.err.println("[CLASSLOADER-AGENT] Failed to install agent: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static void agentmain(String agentArgs, Instrumentation inst) {
        premain(agentArgs, inst);
    }
    
    // Single interceptor class to handle all method calls
    public static class Interceptor {
        
        @RuntimeType
        public static Object intercept(@Origin Method method,
                                     @AllArguments Object[] args,
                                     @This(optional = true) Object instance,
                                     @SuperCall Callable<?> zuper) throws Exception {
            
            String methodName = method.getName();
            String className = method.getDeclaringClass().getName();
            
            try {
                // Detect different types of classloader vulnerabilities
                if ("forName".equals(methodName)) {
                    String targetClass = args.length > 0 ? (String) args[0] : "unknown";
                    logVulnerability("DYNAMIC_CLASS_FORNAME", 
                        "Class.forName() called for: " + targetClass, 
                        isHighRiskClass(targetClass));
                        
                } else if ("loadClass".equals(methodName)) {
                    String targetClass = args.length > 0 ? (String) args[0] : "unknown";
                    String loaderType = instance != null ? instance.getClass().getName() : "unknown";
                    logVulnerability("DYNAMIC_CLASSLOADER_LOAD", 
                        "ClassLoader.loadClass() by " + loaderType + " for: " + targetClass,
                        isHighRiskLoader(loaderType) || isHighRiskClass(targetClass));
                        
                } else if ("defineClass".equals(methodName)) {
                    String targetClass = args.length > 0 ? (String) args[0] : "unknown";
                    String loaderType = instance != null ? instance.getClass().getName() : "unknown";
                    logVulnerability("DYNAMIC_DEFINE_CLASS", 
                        "ClassLoader.defineClass() by " + loaderType + " for: " + targetClass,
                        true); // defineClass is always high risk
                }
                
            } catch (Exception e) {
                // Don't let our monitoring break the application
                System.err.println("[CLASSLOADER-AGENT] Error in interceptor: " + e.getMessage());
            }
            
            // Always call the original method
            return zuper.call();
        }
    }
    
    // Helper methods for risk assessment
    private static boolean isHighRiskClass(String className) {
        if (className == null) return false;
        
        // Check for dangerous class patterns
        return className.contains("Runtime") ||
               className.contains("ProcessBuilder") ||
               className.contains("Script") ||
               className.contains("Compiler") ||
               className.contains("Unsafe") ||
               className.startsWith("sun.") ||
               className.startsWith("com.sun.") ||
               className.contains("javax.script") ||
               className.contains("java.lang.reflect.Proxy") ||
               className.contains("org.springframework.cglib") ||
               className.contains("net.sf.cglib");
    }
    
    private static boolean isHighRiskLoader(String loaderType) {
        if (loaderType == null) return false;
        
        return loaderType.contains("URLClassLoader") ||
               loaderType.contains("RemoteClassLoader") ||
               loaderType.contains("NetworkClassLoader") ||
               loaderType.contains("Custom") ||
               loaderType.contains("Groovy") ||
               loaderType.contains("Script");
    }
    
    private static void logVulnerability(String type, String message, boolean isHighRisk) {
        String riskLevel = isHighRisk ? "HIGH" : "MEDIUM";
        String logMessage = "[SECURITY LOG][AGENT][" + riskLevel + "] " + type + ": " + message;
        
        // Print to both stdout and stderr for maximum visibility
        System.out.println(logMessage);
        System.err.println(logMessage);
    }
}
