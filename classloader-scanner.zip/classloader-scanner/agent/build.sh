#!/bin/bash

# Download Byte Buddy if not present
if [ ! -f "byte-buddy-1.14.10.jar" ]; then
    echo "Downloading Byte Buddy..."
    curl -L -o byte-buddy-1.14.10.jar "https://repo1.maven.org/maven2/net/bytebuddy/byte-buddy/1.14.10/byte-buddy-1.14.10.jar"
fi

# Compile the agent
echo "Compiling ClassLoaderAgent..."
javac -cp byte-buddy-1.14.10.jar ClassLoaderAgent.java

# Create the agent JAR
echo "Creating agent JAR..."
jar cfm classloader-agent.jar MANIFEST.MF *.class

echo "Agent build complete: classloader-agent.jar"
