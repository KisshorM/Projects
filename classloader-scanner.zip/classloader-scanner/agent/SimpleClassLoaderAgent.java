import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple Java Agent for detecting classloader vulnerabilities without external dependencies
 */
public class SimpleClassLoaderAgent {
    
    // Track loaded classes and their sources for pattern analysis
    private static final Set<String> loadedClasses = ConcurrentHashMap.newKeySet();
    private static final Map<String, String> classToLoader = new ConcurrentHashMap<>();
    private static final Map<String, Long> classLoadTiming = new ConcurrentHashMap<>();
    
    public static void premain(String agentArgs, Instrumentation inst) {
        System.out.println("[CLASSLOADER-AGENT] Starting simple dynamic classloader detection");
        
        // Install a custom class file transformer
        inst.addTransformer(new ClassLoaderTransformer(), true);
        
        // Override critical methods using method interception
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("[CLASSLOADER-AGENT] Agent shutting down");
        }));
        
        System.out.println("[CLASSLOADER-AGENT] Simple agent installed successfully");
    }
    
    public static void agentmain(String agentArgs, Instrumentation inst) {
        premain(agentArgs, inst);
    }
    
    static class ClassLoaderTransformer implements ClassFileTransformer {
        
        @Override
        public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, 
                              ProtectionDomain protectionDomain, byte[] classfileBuffer) {
            
            // Monitor class loading activities
            if (className != null) {
                String loaderName = loader != null ? loader.getClass().getName() : "Bootstrap";
                String dotClassName = className.replace('/', '.');
                
                // Track timing and patterns
                loadedClasses.add(dotClassName);
                classToLoader.put(dotClassName, loaderName);
                classLoadTiming.put(dotClassName, System.currentTimeMillis());
                
                // Check for high-risk class patterns
                if (isHighRiskClass(className)) {
                    logVulnerability("DYNAMIC_CLASS_LOAD", 
                        "High-risk class loaded: " + dotClassName + " by " + loaderName, true);
                }
                
                // Check for dangerous classloader types
                if (isHighRiskLoader(loaderName)) {
                    logVulnerability("DYNAMIC_LOADER_USAGE", 
                        "Dangerous classloader used: " + loaderName + " loading " + dotClassName, true);
                }
                
                // Dynamic-specific vulnerability detection
                detectDynamicVulnerabilities(dotClassName, loaderName);
                
                // Monitor specific packages that could indicate RCE attempts
                if (dotClassName.matches(".*\\.(Runtime|ProcessBuilder|Script|Compiler).*")) {
                    logVulnerability("DYNAMIC_RCE_ATTEMPT", 
                        "Potential RCE class detected: " + dotClassName, true);
                }
                
                // Detect suspicious class loading chains
                detectSuspiciousLoadingChains(dotClassName, loaderName);
            }
            
            // Return null to indicate no transformation needed
            return null;
        }
        
        /**
         * Detect vulnerabilities that are only visible during dynamic execution
         */
        private void detectDynamicVulnerabilities(String className, String loaderName) {
            
            // 1. JNDI Injection Detection (runtime-specific)
            if (className.contains("javax.naming") || className.contains("InitialContext")) {
                logVulnerability("DYNAMIC_JNDI_INJECTION", 
                    "JNDI components loaded - potential injection vector: " + className, true);
            }
            
            // 2. JMX Management Interface Abuse (runtime-specific)
            if (className.contains("javax.management") || className.contains("MBeanServer")) {
                logVulnerability("DYNAMIC_JMX_ABUSE", 
                    "JMX management classes loaded - potential remote access: " + className, true);
            }
            
            // 3. Deserialization Gadget Chain Detection (runtime-specific)
            if (isDeserializationGadget(className)) {
                logVulnerability("DYNAMIC_DESERIALIZATION_GADGET", 
                    "Dangerous deserialization gadget loaded: " + className, true);
            }
            
            // 4. Dynamic Proxy Chain Detection (runtime-specific)
            if (className.contains("java.lang.reflect.Proxy") || className.contains("cglib")) {
                logVulnerability("DYNAMIC_PROXY_CHAIN", 
                    "Dynamic proxy detected - potential AOP/RCE vector: " + className, true);
            }
        }
        
        /**
         * Detect suspicious class loading chains that indicate attack patterns
         */
        private void detectSuspiciousLoadingChains(String className, String loaderName) {
            
            // Check for rapid suspicious class loading (possible exploitation attempt)
            long currentTime = System.currentTimeMillis();
            long suspiciousCount = loadedClasses.stream()
                .filter(this::isSuspiciousClassName)
                .map(classLoadTiming::get)
                .filter(Objects::nonNull)
                .filter(time -> currentTime - time < 1000) // Within 1 second
                .count();
            
            if (suspiciousCount >= 3) {
                logVulnerability("DYNAMIC_RAPID_EXPLOITATION", 
                    "Rapid loading of " + suspiciousCount + " suspicious classes detected", true);
            }
            
            // Detect class loading from unusual sources
            if (loaderName.contains("URL") && className.contains("Runtime")) {
                logVulnerability("DYNAMIC_REMOTE_RCE", 
                    "Runtime class loaded via URLClassLoader - potential remote RCE", true);
            }
        }
        
        /**
         * Check if a class name indicates possible deserialization gadget
         */
        private boolean isDeserializationGadget(String className) {
            return className.contains("org.apache.commons.collections") ||
                   className.contains("org.springframework.beans.factory") ||
                   className.contains("com.sun.org.apache.xalan.internal.xsltc.trax") ||
                   className.contains("org.codehaus.groovy.runtime") ||
                   className.contains("com.fasterxml.jackson.databind") ||
                   className.contains("org.hibernate.property");
        }
        
        /**
         * Check if a class name is generally suspicious
         */
        private boolean isSuspiciousClassName(String className) {
            return className.contains("Runtime") ||
                   className.contains("ProcessBuilder") ||
                   className.contains("Script") ||
                   className.contains("javax.naming") ||
                   className.contains("javax.management") ||
                   isDeserializationGadget(className);
        }
        
        private boolean isHighRiskClass(String className) {
            if (className == null) return false;
            
            String dotClassName = className.replace('/', '.');
            
            // Existing patterns
            boolean basicRisk = dotClassName.contains("Runtime") ||
                               dotClassName.contains("ProcessBuilder") ||
                               dotClassName.contains("Script") ||
                               dotClassName.contains("Compiler") ||
                               dotClassName.contains("Unsafe") ||
                               dotClassName.startsWith("sun.") ||
                               dotClassName.startsWith("com.sun.") ||
                               dotClassName.contains("javax.script") ||
                               dotClassName.contains("groovy") ||
                               dotClassName.contains("javascript") ||
                               dotClassName.contains("rhino");
            
            // Dynamic-specific vulnerabilities
            boolean dynamicRisk = 
                // JMX Management vulnerabilities
                dotClassName.contains("javax.management") ||
                dotClassName.contains("MBeanServer") ||
                dotClassName.contains("ObjectName") ||
                
                // JNDI Injection patterns  
                dotClassName.contains("javax.naming") ||
                dotClassName.contains("InitialContext") ||
                dotClassName.contains("DirContext") ||
                
                // Serialization gadgets (commonly loaded dynamically)
                dotClassName.contains("org.apache.commons.collections") ||
                dotClassName.contains("org.springframework.beans") ||
                dotClassName.contains("com.fasterxml.jackson") ||
                dotClassName.contains("org.codehaus.groovy") ||
                
                // Dynamic proxy vulnerabilities
                dotClassName.contains("java.lang.reflect.Proxy") ||
                dotClassName.contains("cglib.proxy") ||
                dotClassName.contains("ByteBuddy") ||
                
                // Template engines (SSTI vulnerabilities)
                dotClassName.contains("freemarker") ||
                dotClassName.contains("velocity") ||
                dotClassName.contains("thymeleaf") ||
                
                // Expression language vulnerabilities
                dotClassName.contains("javax.el") ||
                dotClassName.contains("org.springframework.expression") ||
                dotClassName.contains("ognl");
            
            return basicRisk || dynamicRisk;
        }
        
        private boolean isHighRiskLoader(String loaderName) {
            if (loaderName == null) return false;
            
            return loaderName.contains("URLClassLoader") ||
                   loaderName.contains("RemoteClassLoader") ||
                   loaderName.contains("NetworkClassLoader") ||
                   loaderName.contains("GroovyClassLoader") ||
                   loaderName.contains("ScriptClassLoader") ||
                   loaderName.toLowerCase().contains("custom");
        }
        
        private void logVulnerability(String type, String message, boolean isHighRisk) {
            String riskLevel = isHighRisk ? "HIGH" : "MEDIUM";
            String logMessage = "[SECURITY LOG][AGENT][" + riskLevel + "] " + type + ": " + message;
            
            System.out.println(logMessage);
            System.err.println(logMessage);
        }
    }
    
    // Method interceptor for runtime monitoring (using method overrides)
    static {
        try {
            // Install shutdown hook to monitor agent lifecycle
            System.out.println("[CLASSLOADER-AGENT] Static initializer executed");
        } catch (Exception e) {
            System.err.println("[CLASSLOADER-AGENT] Error in static initializer: " + e.getMessage());
        }
    }
}
