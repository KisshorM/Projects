import streamlit as st
import requests
import json
import io

st.set_page_config(page_title="Java Code Analyzer", layout="wide")
API_BASE = "http://localhost:8000"

# ---------------- Utility ----------------
def display_vulnerability(item):
    st.markdown(f"### 🚨 Line {item['line']} - **{item['type']}**")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Vulnerable Code")
        st.code(item['code'], language='java')
        st.markdown(f"**Description:** {item['description']}")
    with col2:
        st.markdown("#### Sanitized Code")
        st.code(item['sanitized_code'], language='java')
    st.markdown("---")

# --------------- Static File Analyzer ---------------
def analyze_uploaded_files(uploaded_files):
    # Single file
    if len(uploaded_files) == 1 and uploaded_files[0].name.endswith(".zip"):
        # === ZIP ===
        with st.spinner("Analyzing ZIP file..."):
            response = requests.post(
                f"{API_BASE}/analyze_zip",
                files={"file": (uploaded_files[0].name, uploaded_files[0].getvalue())}
            )
            result = response.json()
            if "error" in result:
                st.error(result["error"])
                return
            findings = result.get("findings", [])
            sanitized_files = result.get("sanitized_files", {})
            if not findings:
                st.success("✅ No vulnerabilities found!")
            else:
                st.subheader("Vulnerability Report")
                st.metric("Total Findings", len(findings))
                for item in findings:
                    display_vulnerability(item)
            st.subheader("Sanitized Files")
            for fname, content in sanitized_files.items():
                with st.expander(f"{fname}"):
                    st.code(content, language="java")
    elif len(uploaded_files) >= 1:
        # === One or more .java files ===
        all_findings = []
        all_sanitized = {}
        with st.spinner("Analyzing Java file(s)..."):
            for file in uploaded_files:
                if not file.name.endswith(".java"):
                    continue
                response = requests.post(
                    f"{API_BASE}/analyze",
                    files={"file": (file.name, file.getvalue())}
                )
                result = response.json()
                if "error" in result:
                    st.warning(f"{file.name}: {result['error']}")
                else:
                    all_findings.extend(result.get("findings", []))
                    all_sanitized[file.name] = result.get("sanitized_file", "")
        if not all_findings:
            st.success("✅ No vulnerabilities found!")
        else:
            st.subheader("Vulnerability Report")
            st.metric("Total Findings", len(all_findings))
            for item in all_findings:
                display_vulnerability(item)
            st.subheader("Sanitized Files")
            for fname, content in all_sanitized.items():
                with st.expander(f"{fname}"):
                    st.code(content, language="java")

# ---------------- Raw Code Analyzer ----------------
def analyze_code_input():
    st.subheader("📄 Analyze Raw Java Source Code")
    code = st.text_area("Paste your Java code here", height=250)
    if st.button("Analyze Code"):
        if not code.strip():
            st.warning("Please enter Java code.")
            return
        with st.spinner("Analyzing..."):
            response = requests.post(
                f"{API_BASE}/analyze_code",
                data={"code": code}
            )
            result = response.json()
            if "error" in result:
                st.error(result["error"])
                return
            findings = result.get("findings", [])
            sanitized_code = result.get("sanitized_file", "")
            if not findings:
                st.success("✅ No vulnerabilities found!")
            else:
                st.subheader("Vulnerability Report")
                st.metric("Total Findings", len(findings))
                for item in findings:
                    display_vulnerability(item)
            st.subheader("Sanitized Code")
            st.code(sanitized_code, language="java")

# ---------------- Dynamic Analysis ----------------
def dynamic_analysis(file):
    st.subheader("⚙️ Dynamic Analysis")
    user_input = st.text_area("Optional: Program input", "")
    if st.button("Run Dynamic Analysis"):
        with st.spinner("Running instrumentation and execution..."):
            response = requests.post(
                f"{API_BASE}/instrument_and_run",
                data={"user_input": user_input},
                files={"file": (file.name, file.getvalue())}
            )
            result = response.json()
        if "error" in result:
            st.error(result["error"])
            return

        logs = result.get("logs", [])
        findings = result.get("findings", [])
        raw_output = result.get("raw_output", "")
        inst_code = result.get("instrumented_code", "")
        compile_err = result.get("compile_error", "")
        exec_err = result.get("exec_error", "")

        if findings:
            st.subheader("Instrumentation Warnings")
            for f in findings:
                display_vulnerability(f)

        st.subheader("Runtime Security Logs")
        if logs:
            st.success(f"{len(logs)} runtime event(s) detected")
            for log in logs:
                st.code(log)
        else:
            st.info("No security events triggered at runtime.")

        st.subheader("Program Output")
        st.code(raw_output)
        if compile_err:
            st.error("Compilation Errors")
            st.code(compile_err)
        if exec_err:
            st.error("Runtime Errors")
            st.code(exec_err)

        st.subheader("Instrumented Source Code")
        with st.expander("View Instrumented File"):
            st.code(inst_code, language="java")
        st.download_button("Download Instrumented File", data=inst_code, file_name="instrumented.java", mime="text/plain")

# ---------------- Main App ----------------
def main():
    st.title("🔍 Java Code Security Analyzer")
    st.markdown("Upload Java files or enter raw code to analyze for vulnerabilities.")

    st.markdown("### 📂 Upload (.java, multiple .java, or ZIP)")
    uploaded_files = st.file_uploader(
        "Select a single .java file, multiple files, or a .zip archive",
        type=["java", "zip"],
        accept_multiple_files=True
    )
    if uploaded_files:
        if st.button("🔎 Analyze Uploaded Files"):
            analyze_uploaded_files(uploaded_files)
        # Allow dynamic only if exactly 1 file and it’s a .java
        if len(uploaded_files) == 1 and uploaded_files[0].name.endswith(".java"):
            dynamic_analysis(uploaded_files[0])
        else:
            st.info("⚠️ Dynamic analysis is only supported for a single `.java` file.")

    st.markdown("### 📝 Analyze Raw Java Code")
    analyze_code_input()

if __name__ == "__main__":
    main()
