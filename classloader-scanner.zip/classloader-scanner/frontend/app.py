import streamlit as st
import requests
import json
import io
from collections import defaultdict

st.set_page_config(page_title="Java Classloader Security Analyzer", layout="wide")
API_BASE = "http://localhost:8000"

# ---------------- Utility Functions ----------------
def display_vulnerability(item):
    st.markdown(f"### 🚨 Line {item['line']} - **{item['type']}**")
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Vulnerable Code")
        st.code(item['code'], language='java')
        st.markdown(f"**Description:** {item['description']}")
    with col2:
        st.markdown("#### Sanitized Code")
        st.code(item['sanitized_code'], language='java')
    st.markdown("---")

def group_dynamic_logs(logs):
    """Group dynamic security logs by vulnerability type"""
    groups = defaultdict(list)
    
    for log in logs:
        if "DYNAMIC_JNDI_INJECTION" in log:
            groups["🔴 JNDI Injection Vulnerabilities"].append(log)
        elif "DYNAMIC_JMX_ABUSE" in log:
            groups["🔴 JMX Management Abuse"].append(log)
        elif "DYNAMIC_PROXY_CHAIN" in log:
            groups["🔴 Dynamic Proxy Exploitation"].append(log)
        elif "DYNAMIC_RAPID_EXPLOITATION" in log:
            groups["🔴 Rapid Exploitation Attempts"].append(log)
        elif "DYNAMIC_DESERIALIZATION_GADGET" in log:
            groups["🔴 Deserialization Gadgets"].append(log)
        elif "DYNAMIC_CLASS_LOAD" in log:
            groups["🟡 Suspicious Class Loading"].append(log)
        elif "DYNAMIC_LOADER_USAGE" in log:
            groups["🟡 Dangerous ClassLoader Usage"].append(log)
        elif "DYNAMIC_RCE_ATTEMPT" in log:
            groups["🔴 Remote Code Execution Attempts"].append(log)
        elif "DYNAMIC_REMOTE_RCE" in log:
            groups["🔴 Remote RCE Vectors"].append(log)
        else:
            groups["🟢 Other Security Events"].append(log)
    
    return groups

def get_risk_level_from_log(log):
    """Extract risk level from security log"""
    if "[HIGH]" in log:
        return "🔴 HIGH RISK", "error"
    elif "[MEDIUM]" in log:
        return "🟡 MEDIUM RISK", "warning"
    else:
        return "🟢 LOW RISK", "success"

def display_dynamic_vulnerability_groups(grouped_logs):
    """Display dynamic vulnerabilities grouped by type"""
    if not grouped_logs:
        st.info("🛡️ No dynamic security events detected")
        return
    
    st.subheader("🔍 Dynamic Security Analysis Results")
    
    total_events = sum(len(events) for events in grouped_logs.values())
    high_risk_count = sum(1 for logs in grouped_logs.values() for log in logs if "[HIGH]" in log)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Events", total_events)
    with col2:
        st.metric("High Risk Events", high_risk_count)
    with col3:
        st.metric("Vulnerability Categories", len(grouped_logs))
    
    # Sort groups by risk level (high risk first)
    sorted_groups = sorted(grouped_logs.items(), key=lambda x: (
        0 if "🔴" in x[0] else 1 if "🟡" in x[0] else 2,
        x[0]
    ))
    
    # Display each group
    for group_name, events in sorted_groups:
        with st.expander(f"{group_name} ({len(events)} events)", expanded=("🔴" in group_name)):
            
            # Count risk levels in this group
            high_count = sum(1 for event in events if "[HIGH]" in event)
            medium_count = sum(1 for event in events if "[MEDIUM]" in event)
            
            if high_count > 0:
                st.error(f"⚠️ {high_count} HIGH RISK events in this category")
            elif medium_count > 0:
                st.warning(f"⚠️ {medium_count} MEDIUM RISK events in this category")
            else:
                st.info("ℹ️ Low risk events in this category")
            
            # Display events in a more organized way
            for i, event in enumerate(events, 1):
                risk_label, risk_type = get_risk_level_from_log(event)
                
                # Clean up the log message for display
                clean_event = event.replace("[SECURITY LOG][AGENT]", "").replace("[HIGH]", "").replace("[MEDIUM]", "").replace("[LOW]", "").strip()
                
                # Extract vulnerability type and message
                if ":" in clean_event:
                    vuln_type, message = clean_event.split(":", 1)
                    vuln_type = vuln_type.strip()
                    message = message.strip()
                else:
                    vuln_type = "Unknown"
                    message = clean_event
                
                with st.container():
                    if risk_type == "error":
                        st.error(f"**Event {i}:** {vuln_type}")
                    elif risk_type == "warning":
                        st.warning(f"**Event {i}:** {vuln_type}")
                    else:
                        st.info(f"**Event {i}:** {vuln_type}")
                    
                    st.code(message, language="text")
                
            st.markdown("---")

# --------------- Static Analysis Functions ---------------
def perform_static_analysis(file_content, filename):
    """Perform static analysis on Java code"""
    try:
        with st.spinner("🔍 Running static analysis..."):
            response = requests.post(
                f"{API_BASE}/analyze",
                files={"file": (filename, file_content)}
            )
            result = response.json()
            
            if "error" in result:
                st.error(f"❌ Static analysis failed: {result['error']}")
                return None
                
            return result
    except Exception as e:
        st.error(f"❌ Error during static analysis: {str(e)}")
        return None

def display_static_results(result):
    """Display static analysis results"""
    if not result:
        return
        
    findings = result.get("findings", [])
    sanitized_file = result.get("sanitized_file", "")
    
    st.subheader("📋 Static Analysis Results")
    
    if not findings:
        st.success("✅ No static vulnerabilities found!")
        return
    
    # Count different risk levels
    high_risk = ["Insecure Reflection", "ClassLoader Risk", "Bytecode Injection", "Remote Code Execution"]
    high_count = sum(1 for f in findings if f['type'] in high_risk)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Vulnerabilities", len(findings))
    with col2:
        st.metric("High Risk", high_count)
    with col3:
        st.metric("Other Risk", len(findings) - high_count)
    
    # Group static findings by type for better organization
    grouped_findings = defaultdict(list)
    for finding in findings:
        grouped_findings[finding['type']].append(finding)
    
    # Sort by risk level
    sorted_findings = sorted(grouped_findings.items(), key=lambda x: (
        0 if x[0] in high_risk else 1,
        x[0]
    ))
    
    for vuln_type, type_findings in sorted_findings:
        risk_icon = "🔴" if vuln_type in high_risk else "🟡"
        with st.expander(f"{risk_icon} {vuln_type} ({len(type_findings)} instances)", expanded=(vuln_type in high_risk)):
            for finding in type_findings:
                display_vulnerability(finding)
    
    if sanitized_file:
        with st.expander("📝 View Sanitized Code"):
            st.code(sanitized_file, language="java")

# --------------- Dynamic Analysis Functions ---------------
def perform_dynamic_analysis(file_content, filename, user_input=""):
    """Perform dynamic analysis on Java code"""
    try:
        with st.spinner("⚙️ Running dynamic analysis (compiling and executing with agent)..."):
            response = requests.post(
                f"{API_BASE}/analyze_dynamic",
                files={"file": (filename, file_content)},
                data={"user_input": user_input}
            )
            result = response.json()
            
            if "error" in result:
                st.error(f"❌ Dynamic analysis failed: {result['error']}")
                return None
                
            return result
    except Exception as e:
        st.error(f"❌ Error during dynamic analysis: {str(e)}")
        return None

def display_dynamic_results(result):
    """Display dynamic analysis results"""
    if not result:
        return
    
    dynamic_logs = result.get("dynamic_logs", [])
    program_output = result.get("program_output", "")
    program_errors = result.get("program_errors", "")
    execution_success = result.get("execution_success", False)
    compile_error = result.get("compile_error", "")
    
    # Display execution status
    col1, col2 = st.columns(2)
    with col1:
        if execution_success:
            st.success("✅ Program executed successfully")
        else:
            st.error("❌ Program execution failed")
    
    with col2:
        st.metric("Dynamic Events Detected", len(dynamic_logs))
    
    # Group and display dynamic vulnerabilities
    grouped_logs = group_dynamic_logs(dynamic_logs)
    display_dynamic_vulnerability_groups(grouped_logs)
    
    # Display program output and errors
    if program_output.strip():
        with st.expander("📄 Program Output"):
            st.code(program_output, language="text")
    
    if program_errors.strip():
        with st.expander("⚠️ Program Runtime Errors"):
            st.code(program_errors, language="text")
    
    if compile_error.strip():
        with st.expander("❌ Compilation Errors"):
            st.code(compile_error, language="text")

# --------------- Raw Code Analysis ---------------
def analyze_raw_code():
    st.subheader("📝 Analyze Raw Java Code")
    
    code = st.text_area("Paste your Java code here:", height=300, help="Enter your Java source code for analysis")
    
    if not code.strip():
        st.info("👆 Enter Java code above to analyze")
        return
    
    # Analysis options
    st.markdown("### Choose Analysis Type")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🔍 Static Analysis Only", use_container_width=True):
            st.markdown("#### 📋 Static Analysis Results")
            result = perform_static_analysis(code.encode(), "RawCode.java")
            if result:
                display_static_results(result)
    
    with col2:
        if st.button("⚙️ Dynamic Analysis Only", use_container_width=True):
            user_input = st.text_input("Program input (optional):", key="dynamic_input")
            st.markdown("#### 🔍 Dynamic Analysis Results")
            result = perform_dynamic_analysis(code.encode(), "RawCode.java", user_input)
            if result:
                display_dynamic_results(result)
    
    with col3:
        if st.button("🚀 Both Analyses", use_container_width=True):
            user_input_combined = st.text_input("Program input for dynamic analysis (optional):", key="combined_input")
            
            # Run both analyses side by side
            col_static, col_dynamic = st.columns(2)
            
            with col_static:
                st.markdown("#### 📋 Static Analysis")
                static_result = perform_static_analysis(code.encode(), "RawCode.java")
                if static_result:
                    display_static_results(static_result)
            
            with col_dynamic:
                st.markdown("#### 🔍 Dynamic Analysis")
                dynamic_result = perform_dynamic_analysis(code.encode(), "RawCode.java", user_input_combined)
                if dynamic_result:
                    display_dynamic_results(dynamic_result)

# --------------- File Upload Analysis ---------------
def analyze_uploaded_files():
    st.subheader("📂 Upload Java Files for Analysis")
    
    uploaded_files = st.file_uploader(
        "Choose Java files:",
        type=["java"],
        accept_multiple_files=True,
        help="Upload one or more .java files for security analysis"
    )
    
    if not uploaded_files:
        st.info("👆 Upload .java files to analyze")
        return
    
    # Show uploaded files
    st.success(f"📁 **{len(uploaded_files)} file(s) uploaded successfully:**")
    for file in uploaded_files:
        st.write(f"• `{file.name}` ({len(file.getvalue())} bytes)")
    
    # Analysis options for uploaded files
    st.markdown("### Choose Analysis Type")
    
    analysis_type = st.radio(
        "Select analysis mode:",
        ["Static Analysis Only", "Dynamic Analysis Only", "Both Static + Dynamic"],
        help="Choose the type of security analysis to perform"
    )
    
    user_input = ""
    if "Dynamic" in analysis_type:
        user_input = st.text_input("Program input for dynamic analysis (optional):", key="upload_input")
    
    if st.button("🚀 Start Analysis", use_container_width=True):
        
        for i, file in enumerate(uploaded_files):
            st.markdown(f"## 📄 Analysis Results for: `{file.name}`")
            
            file_content = file.getvalue()
            
            if analysis_type == "Static Analysis Only":
                result = perform_static_analysis(file_content, file.name)
                if result:
                    display_static_results(result)
                    
            elif analysis_type == "Dynamic Analysis Only":
                result = perform_dynamic_analysis(file_content, file.name, user_input)
                if result:
                    display_dynamic_results(result)
                    
            else:  # Both analyses
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("### 📋 Static Analysis")
                    static_result = perform_static_analysis(file_content, file.name)
                    if static_result:
                        display_static_results(static_result)
                
                with col2:
                    st.markdown("### 🔍 Dynamic Analysis") 
                    dynamic_result = perform_dynamic_analysis(file_content, file.name, user_input)
                    if dynamic_result:
                        display_dynamic_results(dynamic_result)
            
            if i < len(uploaded_files) - 1:
                st.markdown("---")

# --------------- Main App ---------------
def main():
    st.title("🔍 Java Classloader Security Analyzer")
    st.markdown("""
    **Enhanced security analysis combining static code scanning with dynamic runtime monitoring.**
    
    - 📋 **Static Analysis**: Detects 18+ vulnerability patterns in source code
    - 🔍 **Dynamic Analysis**: Monitors 4+ runtime-only vulnerabilities using Java agent
    - 🚀 **Combined Analysis**: Get complete security coverage with both approaches
    """)
    
    # Create tabs for different analysis modes
    tab1, tab2, tab3 = st.tabs(["📂 File Upload", "📝 Raw Code", "📚 Test Cases"])
    
    with tab1:
        analyze_uploaded_files()
    
    with tab2:
        analyze_raw_code()
    
    with tab3:
        st.subheader("🧪 Dynamic Vulnerability Test Cases")
        st.markdown("""
        Test the dynamic analysis capabilities with these pre-built test cases:
        """)
        
        test_cases = [
            ("JNDIInjectionTest.java", "Tests JNDI injection vulnerability detection", "JNDI Injection"),
            ("JMXAbuseTest.java", "Tests JMX management interface abuse detection", "JMX Abuse"),
            ("DynamicProxyTest.java", "Tests dynamic proxy exploitation chain detection", "Dynamic Proxy"),
            ("RapidExploitationTest.java", "Tests rapid exploitation pattern detection", "Rapid Exploitation"),
        ]
        
        for filename, description, vuln_type in test_cases:
            with st.expander(f"🧪 {filename} - {vuln_type}"):
                st.markdown(f"**Description:** {description}")
                st.code(f"""
# To test manually:
cd test-cases/
javac {filename}
java -javaagent:../agent/simple-classloader-agent.jar {filename.replace('.java', '')}
                """, language="bash")
    
    # Sidebar with information
    with st.sidebar:
        st.markdown("### 🛡️ Detection Capabilities")
        
        with st.expander("📋 Static Analysis (18+ patterns)"):
            st.markdown("""
            - 🔴 Insecure Reflection
            - 🔴 ClassLoader Risks
            - 🔴 Command Injection
            - 🔴 Path Traversal
            - 🟡 Unsafe Deserialization
            - 🟡 XXE Vulnerabilities
            - 🟡 Reflection Abuse
            - And 11+ more patterns...
            """)
        
        with st.expander("🔍 Dynamic Analysis (4+ patterns)"):
            st.markdown("""
            - 🔴 **JNDI Injection** - Runtime JNDI context creation
            - 🔴 **JMX Management Abuse** - JMX MBean access
            - 🔴 **Dynamic Proxy Chains** - AOP exploitation vectors
            - 🔴 **Rapid Exploitation** - Automated attack patterns
            - 🟡 Suspicious Class Loading
            - 🟡 Dangerous ClassLoader Usage
            """)
        
        st.markdown("---")
        st.markdown("### ⚙️ API Endpoints")
        st.code("""
POST /analyze
- Static analysis only

POST /analyze_dynamic  
- Static + Dynamic analysis
        """, language="text")

if __name__ == "__main__":
    main()
