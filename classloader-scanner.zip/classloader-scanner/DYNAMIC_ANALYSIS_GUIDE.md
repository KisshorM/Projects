# Java Classloader Security Analyzer

A comprehensive security analysis tool for Java applications that combines **static analysis** and **dynamic runtime detection** to identify classloader-related vulnerabilities and security risks.

## 🏗️ Project Architecture

```
classloader-scanner/
├── analyzer/           # Static analysis engine (Java)
│   ├── Analyzer.java          # Main static analyzer with 18+ vulnerability patterns
│   ├── SecurityLogger.java    # Security event logging utility
│   └── DynamicVulnTest.java  # Test cases for static analysis
├── agent/             # Dynamic runtime monitoring agent (Java)
│   ├── SimpleClassLoaderAgent.java  # Runtime classloader monitoring
│   └── simple-classloader-agent.jar # Compiled agent
├── backend/           # FastAPI REST API server (Python)
│   └── main.py               # API endpoints for analysis services  
├── frontend/          # Streamlit web interface (Python)
│   └── app.py                # Web UI for file upload and analysis
└── test-cases/        # Dynamic vulnerability test cases
    ├── JNDIInjectionTest.java
    ├── JMXAbuseTest.java  
    ├── DynamicProxyTest.java
    └── RapidExploitationTest.java
```

## 🔍 Detection Capabilities

### Static Analysis (18+ Vulnerability Types)
The static analyzer detects code patterns that indicate potential security issues:

- **Insecure Reflection**: `Class.forName()` with unvalidated input
- **ClassLoader Risks**: `loadClass()`, `defineClass()` misuse
- **Remote Code Execution**: `URLClassLoader` with external URLs
- **Command Injection**: `Runtime.exec()`, `ProcessBuilder`
- **Path Traversal**: Unsafe file operations
- **Deserialization**: `readObject()` vulnerabilities
- **XXE**: XML parser misconfigurations
- **Reflection Abuse**: `invoke()`, `setAccessible()`
- And 10+ more patterns...

### Dynamic Analysis (4 New Vulnerability Types)

#### 1. **JNDI Injection Detection** 🔥
- **What it detects**: Runtime loading of JNDI components that could be exploited for remote code execution
- **Why dynamic**: JNDI lookups and context creation only happen at runtime
- **Risk Level**: HIGH
- **Example**: Loading `javax.naming.InitialContext` for `ldap://` lookups

#### 2. **JMX Management Abuse** 🔥  
- **What it detects**: Access to JMX MBean servers that could allow remote management interface abuse
- **Why dynamic**: JMX beans are registered and accessed at runtime
- **Risk Level**: HIGH  
- **Example**: `ManagementFactory.getPlatformMBeanServer()` for remote control

#### 3. **Dynamic Proxy Chain Detection** 🔥
- **What it detects**: Creation of dynamic proxies that could be used for AOP-based attacks
- **Why dynamic**: Proxies are created at runtime with `Proxy.newProxyInstance()`
- **Risk Level**: HIGH
- **Example**: Proxy chains used in deserialization gadgets

#### 4. **Rapid Exploitation Pattern** 🔥
- **What it detects**: Multiple suspicious classes loaded in quick succession (within 1 second)
- **Why dynamic**: Timing patterns only visible during execution
- **Risk Level**: HIGH
- **Example**: Loading Runtime → ProcessBuilder → ScriptEngine → JNDI rapidly

## 🚀 Quick Start

### Prerequisites
- Java 11+ 
- Python 3.8+
- Required Python packages: `fastapi`, `uvicorn`, `streamlit`, `python-multipart`

### 1. Start the Backend API
```bash
cd backend/
python main.py
# Server starts on http://localhost:8000
```

### 2. Start the Frontend (Optional)
```bash
cd frontend/
streamlit run app.py  
# UI available at http://localhost:8501
```

### 3. Test the Enhanced Detection

#### API Endpoints
- **`POST /analyze`** - Static analysis only
- **`POST /analyze_dynamic`** - Static + Dynamic analysis (NEW!)

#### Example API Usage
```bash
# Static analysis only
curl -X POST "http://localhost:8000/analyze" -F "file=@test-cases/JNDIInjectionTest.java"

# Dynamic analysis (static + runtime monitoring)
curl -X POST "http://localhost:8000/analyze_dynamic" -F "file=@test-cases/JNDIInjectionTest.java" -F "user_input="
```

## 🧪 Test Cases

### Running Individual Tests
```bash
# Test JNDI injection detection
cd test-cases/
javac JNDIInjectionTest.java
java -javaagent:../agent/simple-classloader-agent.jar JNDIInjectionTest

# Test JMX abuse detection  
javac JMXAbuseTest.java
java -javaagent:../agent/simple-classloader-agent.jar JMXAbuseTest

# Test dynamic proxy detection
javac DynamicProxyTest.java  
java -javaagent:../agent/simple-classloader-agent.jar DynamicProxyTest

# Test rapid exploitation detection
javac RapidExploitationTest.java
java -javaagent:../agent/simple-classloader-agent.jar RapidExploitationTest
```

### Expected Output Example
```
[CLASSLOADER-AGENT] Starting simple dynamic classloader detection
[SECURITY LOG][AGENT][HIGH] DYNAMIC_JNDI_INJECTION: JNDI components loaded - potential injection vector: javax.naming.InitialContext
[SECURITY LOG][AGENT][HIGH] DYNAMIC_JMX_ABUSE: JMX management classes loaded - potential remote access: javax.management.MBeanServer
[SECURITY LOG][AGENT][HIGH] DYNAMIC_PROXY_CHAIN: Dynamic proxy detected - potential AOP/RCE vector: com.sun.proxy.$Proxy0
[SECURITY LOG][AGENT][HIGH] DYNAMIC_RAPID_EXPLOITATION: Rapid loading of 4 suspicious classes detected
```

## 🔧 Configuration

### Agent Configuration
The agent runs automatically when attached via `-javaagent:` parameter. No additional configuration required.

### Backend Configuration  
Edit `backend/main.py` to modify:
- Server host/port settings
- Timeout values for analysis
- Agent JAR path

### Adding Custom Vulnerability Patterns
1. **Static patterns**: Edit `analyzer/Analyzer.java` → `MethodCallVisitor.visit()`
2. **Dynamic patterns**: Edit `agent/SimpleClassLoaderAgent.java` → `detectDynamicVulnerabilities()`

## 📊 Analysis Results

### Static Analysis Response
```json
{
  "findings": [
    {
      "line": 15,
      "type": "Insecure Reflection", 
      "description": "Class.forName() with unvalidated input",
      "code": "Class.forName(userInput);",
      "sanitized_code": "if (ALLOWED_CLASSES.contains(className)) { Class.forName(className); }"
    }
  ],
  "sanitized_file": "// Complete sanitized source code..."
}
```

### Dynamic Analysis Response  
```json
{
  "static_findings": [...],
  "dynamic_logs": [
    "[SECURITY LOG][AGENT][HIGH] DYNAMIC_JNDI_INJECTION: JNDI components loaded - potential injection vector: javax.naming.InitialContext",
    "[SECURITY LOG][AGENT][HIGH] DYNAMIC_RAPID_EXPLOITATION: Rapid loading of 3 suspicious classes detected"
  ],
  "program_output": "Application output...",
  "execution_success": true
}
```

## 🛠️ Development

### Building the Agent
```bash
cd agent/
javac SimpleClassLoaderAgent.java
jar cfm simple-classloader-agent.jar SIMPLE-MANIFEST.MF SimpleClassLoaderAgent*.class
```

### Running Tests During Development
```bash
# Test static analysis
java -cp analyzer/:analyzer/javaparser-core-3.26.4.jar Analyzer test-file.java

# Test dynamic analysis
java -javaagent:agent/simple-classloader-agent.jar TestClass
```

## 🔒 Security Considerations

### What This Tool Detects
- ✅ Known vulnerable patterns in source code
- ✅ Runtime classloader abuse
- ✅ JNDI injection vectors
- ✅ JMX management interface abuse
- ✅ Dynamic proxy exploitation chains
- ✅ Rapid exploitation attempts
- ✅ Deserialization gadget loading

### Limitations  
- ⚠️ Cannot detect zero-day vulnerabilities
- ⚠️ May have false positives for legitimate use cases
- ⚠️ Dynamic analysis requires code execution
- ⚠️ Agent adds runtime overhead

## 🤝 Contributing

1. **Add new static patterns**: Extend `analyzer/Analyzer.java`
2. **Add new dynamic patterns**: Extend `agent/SimpleClassLoaderAgent.java` 
3. **Create test cases**: Add to `test-cases/` directory
4. **Update documentation**: Keep this README current

## 📝 License

This project is for educational and security research purposes. Use responsibly and in accordance with your organization's security policies.

## 🐛 Troubleshooting

### Common Issues

**Agent not loading:**
```bash
# Verify agent exists and is executable
ls -la agent/simple-classloader-agent.jar
```

**API server not starting:**
```bash
# Install dependencies
pip install fastapi uvicorn python-multipart
```

**Java compilation errors:**
```bash
# Ensure Java 11+ is installed
java -version
javac -version
```

### Debug Mode
Add `-verbose:class` to see detailed class loading:
```bash
java -verbose:class -javaagent:agent/simple-classloader-agent.jar TestClass
```

---

## 🎯 Key Benefits of Dynamic Analysis

1. **Runtime Context**: Detects vulnerabilities only visible during execution
2. **Attack Pattern Recognition**: Identifies exploitation sequences and timing
3. **Zero False Positives**: Only flags actually loaded/used components  
4. **Real-world Accuracy**: Captures actual runtime behavior vs. static possibilities

This enhanced tool provides comprehensive security analysis by combining the best of both static code analysis and dynamic runtime monitoring!
