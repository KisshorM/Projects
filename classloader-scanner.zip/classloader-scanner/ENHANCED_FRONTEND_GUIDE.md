# Enhanced Frontend Guide

## 🎨 New Frontend Features

The enhanced frontend (`app.py`) now provides **independent static and dynamic analysis** with **grouped vulnerability display** for better security assessment.

## 🚀 Key Improvements

### ✅ **Independent Analysis Modes**
- **Static Only**: Runs code analysis without execution
- **Dynamic Only**: Executes code with runtime monitoring
- **Combined**: Runs both analyses side-by-side

### ✅ **Grouped Dynamic Vulnerabilities**
Dynamic security events are now organized by category:

- 🔴 **JNDI Injection Vulnerabilities**
- 🔴 **JMX Management Abuse** 
- 🔴 **Dynamic Proxy Exploitation**
- 🔴 **Rapid Exploitation Attempts**
- 🔴 **Deserialization Gadgets**
- 🟡 **Suspicious Class Loading**
- 🟡 **Dangerous ClassLoader Usage**
- 🟢 **Other Security Events**

### ✅ **Enhanced UI/UX**
- Risk-based color coding (🔴 High, 🟡 Medium, 🟢 Low)
- Expandable vulnerability groups
- Cleaner event display with better formatting
- Metrics dashboard showing counts and risk levels

## 📱 How to Use

### 1. **Start the Applications**

```bash
# Backend API (Terminal 1)
cd backend/
python main.py

# Frontend UI (Terminal 2)  
cd frontend/
streamlit run app.py
```

### 2. **Access the Interface**
- Open http://localhost:8501 in your browser
- Choose between "File Upload" or "Raw Code" tabs

### 3. **Analysis Options**

#### **File Upload Tab:**
1. Upload one or more `.java` files
2. Choose analysis type:
   - Static Analysis Only
   - Dynamic Analysis Only  
   - Both Static + Dynamic
3. Optionally provide program input for dynamic analysis
4. Click "Start Analysis"

#### **Raw Code Tab:**
1. Paste Java code in the text area
2. Choose one of three buttons:
   - 🔍 **Static Analysis Only**
   - ⚙️ **Dynamic Analysis Only** 
   - 🚀 **Both Analyses** (side-by-side view)

## 📊 Reading the Results

### **Static Analysis Results**
```
📋 Static Analysis Results
├── 🔴 High Risk Vulnerabilities (auto-expanded)
│   ├── Insecure Reflection (2 instances)
│   └── ClassLoader Risk (1 instance)
└── 🟡 Other Vulnerabilities
    ├── Path Traversal (3 instances)
    └── Insecure Randomness (1 instance)
```

### **Dynamic Analysis Results**
```
🔍 Dynamic Security Analysis Results
├── Total Events: 12
├── High Risk Events: 8
└── Vulnerability Categories: 4

🔴 JNDI Injection Vulnerabilities (3 events) [EXPANDED]
├── ⚠️ 3 HIGH RISK events in this category  
├── Event 1: DYNAMIC_JNDI_INJECTION
│   └── JNDI components loaded - potential injection vector: javax.naming.InitialContext
└── Event 2: DYNAMIC_JNDI_INJECTION
    └── JNDI components loaded - potential injection vector: javax.naming.Context

🔴 Rapid Exploitation Attempts (7 events) [EXPANDED]
└── Multiple rapid class loading events...

🟡 Suspicious Class Loading (2 events)
└── Various sun.* classes loaded...
```

## 🧪 Testing the Enhanced Frontend

### **Test with Combined Vulnerabilities:**
```java
import javax.naming.InitialContext;

public class CombinedVulnTest {
    public static void main(String[] args) throws Exception {
        // Static vulnerability
        Class.forName(args.length > 0 ? args[0] : "java.lang.Runtime");
        
        // Dynamic vulnerability  
        InitialContext ctx = new InitialContext();
        
        System.out.println("Test completed!");
    }
}
```

**Expected Results:**
- **Static**: Detects "Insecure Reflection" vulnerability
- **Dynamic**: Detects "JNDI Injection" and "Rapid Exploitation" events

### **Test Individual Analysis Modes:**

1. **Static Only**: Upload the file and select "Static Analysis Only"
   - Should show reflection vulnerability
   - No program execution occurs

2. **Dynamic Only**: Upload the file and select "Dynamic Analysis Only" 
   - Should show JNDI injection and rapid exploitation events
   - Program executes successfully

3. **Combined**: Select "Both Static + Dynamic"
   - Should show both results side-by-side
   - Gives complete security picture

## 🎯 Benefits of the Enhanced Frontend

### **For Security Analysts:**
- **Clear Risk Prioritization**: High-risk vulnerabilities displayed first
- **Grouped Findings**: Related vulnerabilities grouped together
- **Independent Analysis**: Choose appropriate analysis type for the situation

### **For Developers:**
- **Actionable Results**: Clear separation between compile-time and runtime issues
- **Comprehensive Coverage**: Both static patterns and dynamic behaviors
- **Easy Testing**: Upload files or paste code directly

### **For Operations:**
- **Risk Assessment**: Clear metrics and risk levels
- **Audit Trail**: Complete program output and error logs
- **Flexible Deployment**: Choose static-only for fast scanning or dynamic for deep analysis

## 🔧 Configuration

### **API Endpoints Used:**
- `POST /analyze` - Static analysis only
- `POST /analyze_dynamic` - Static + Dynamic analysis

### **Customization:**
Edit `frontend/app.py` to:
- Modify vulnerability grouping logic in `group_dynamic_logs()`
- Change risk color coding in `get_risk_level_from_log()`
- Add new vulnerability categories as needed

## 🚀 Quick Start Commands

```bash
# Test static analysis
curl -X POST "http://localhost:8000/analyze" -F "file=@test-cases/CombinedVulnTest.java"

# Test dynamic analysis  
curl -X POST "http://localhost:8000/analyze_dynamic" -F "file=@test-cases/CombinedVulnTest.java" -F "user_input="

# Start frontend
streamlit run frontend/app.py
```

The enhanced frontend provides a professional, user-friendly interface for comprehensive Java security analysis with both static and dynamic capabilities!
