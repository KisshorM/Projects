import java.util.Scanner;

public class DynamicVulnTest {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        // Vulnerability 1: Insecure Reflection
        System.out.print("Enter a class name to load: ");
        String clazzName = scanner.nextLine();
        Class.forName(clazzName); // This triggers "Insecure Reflection"

        // Vulnerability 2: Command Injection
        System.out.print("Enter a shell command to execute: ");
        String cmd = scanner.nextLine();
        Runtime.getRuntime().exec(cmd); // This triggers "Command Injection"
    }
}
