import com.github.javaparser.*;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.io.*;
import java.nio.file.Files;
import java.util.*;

public class Analyzer {

    private static String ensureLoggerImport(String code) {
        String importLine = "import analyzer.sec.SecurityLogger;";
        if (code.contains(importLine))
            return code;

        String[] lines = code.split("\\r?\\n");
        StringBuilder sb = new StringBuilder();
        boolean importInserted = false;

        for (int i = 0; i < lines.length; i++) {
            sb.append(lines[i]).append("\n");
            if (!importInserted && (lines[i].startsWith("package ") || lines[i].startsWith("import "))) {
                if ((i + 1 == lines.length) || (!lines[i + 1].startsWith("import "))) {
                    sb.append(importLine).append("\n");
                    importInserted = true;
                }
            }
        }

        if (!importInserted) {
            sb.insert(0, importLine + "\n");
        }

        return sb.toString();
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("{ \"error\": \"No file specified.\" }");
            return;
        }

        String filePath = args[0];
        boolean instrumentationMode = args.length > 1 && args[1].equals("--instrument");

        try {
            File file = new File(filePath);
            List<String> codeLines = Files.readAllLines(file.toPath());
            CompilationUnit cu = StaticJavaParser.parse(file);
            List<Map<String, Object>> findings = new ArrayList<>();
            Map<Integer, String> sanitizedReplacements = new HashMap<>();

            cu.accept(new MethodCallVisitor(codeLines, findings, sanitizedReplacements, instrumentationMode), null);

            String sanitizedFile = generateSanitizedFile(codeLines, sanitizedReplacements);
            if (instrumentationMode) {
                sanitizedFile = ensureLoggerImport(sanitizedFile);
            }

            System.out.println(toJson(findings, sanitizedFile));

        } catch (Exception e) {
            System.out.println("{ \"error\": \"" + e.getMessage().replace("\"", "\\\"") + "\" }");
        }
    }

    private static String generateSanitizedFile(List<String> codeLines, Map<Integer, String> replacements) {
        StringBuilder sanitizedFile = new StringBuilder();
        for (int i = 0; i < codeLines.size(); i++) {
            int lineNumber = i + 1;
            sanitizedFile.append(replacements.getOrDefault(lineNumber, codeLines.get(i))).append("\n");
        }
        return sanitizedFile.toString();
    }

    private static String toJson(List<Map<String, Object>> findings, String sanitizedFile) {
        StringBuilder json = new StringBuilder("{\"findings\":[");
        for (int i = 0; i < findings.size(); i++) {
            Map<String, Object> map = findings.get(i);
            json.append("{")
                .append("\"line\":").append(map.get("line")).append(",")
                .append("\"type\":\"").append(map.get("type")).append("\",")
                .append("\"description\":\"").append(map.get("description")).append("\",")
                .append("\"code\":\"").append(escapeJson(map.get("code").toString())).append("\",")
                .append("\"sanitized_code\":\"").append(escapeJson(map.get("sanitized_code").toString())).append("\"")
                .append("}");
            if (i < findings.size() - 1)
                json.append(",");
        }
        json.append("],\"sanitized_file\":\"").append(escapeJson(sanitizedFile)).append("\"}");
        return json.toString();
    }

    private static String escapeJson(String input) {
        return input.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
    }

    private static class MethodCallVisitor extends VoidVisitorAdapter<Void> {
        private final List<String> codeLines;
        private final List<Map<String, Object>> findings;
        private final Map<Integer, String> sanitizedReplacements;
        private final boolean instrumentationMode;

        public MethodCallVisitor(List<String> codeLines, List<Map<String, Object>> findings,
                                 Map<Integer, String> sanitizedReplacements, boolean instrumentationMode) {
            this.codeLines = codeLines;
            this.findings = findings;
            this.sanitizedReplacements = sanitizedReplacements;
            this.instrumentationMode = instrumentationMode;
        }

        @Override
        public void visit(MethodCallExpr mce, Void arg) {
            super.visit(mce, arg);
            int line = mce.getBegin().map(p -> p.line).orElse(-1);
            Map<String, Object> entry = new HashMap<>();
            entry.put("line", line);
            entry.put("code", (line > 0 && line <= codeLines.size()) ? codeLines.get(line - 1).trim() : "// Code unavailable");

            String methodName = mce.getNameAsString();
            String fullCall = mce.toString();
            boolean found = false;

            // --- All 18 tests ---
            if (methodName.equals("forName")) {
                entry.put("type", "Insecure Reflection");
                entry.put("description", "Class.forName() with unvalidated input");
                entry.put("sanitized_code", "if (ALLOWED_CLASSES.contains(className)) { Class.forName(className); }");
                found = true;
            } else if (methodName.equals("loadClass")) {
                entry.put("type", "ClassLoader Risk");
                entry.put("description", "ClassLoader.loadClass() detected");
                entry.put("sanitized_code", "if (isTrusted(classLoader)) { classLoader.loadClass(name); }");
                found = true;
            } else if (methodName.equals("defineClass")) {
                entry.put("type", "Bytecode Injection");
                entry.put("description", "defineClass() can be misused");
                entry.put("sanitized_code", "defineClass(...validatedByteCode...)");
                found = true;
            } else if (fullCall.contains("URLClassLoader")) {
                entry.put("type", "Remote Code Execution");
                entry.put("description", "URLClassLoader loading risky external jars");
                entry.put("sanitized_code", "new URLClassLoader(validatedUrls)");
                found = true;
            } else if (methodName.equals("getSystemClassLoader")) {
                entry.put("type", "ClassLoader Manipulation");
                entry.put("description", "System class loader access detected");
                entry.put("sanitized_code", "// avoid system classloader access");
                found = true;
            } else if (methodName.equals("setContextClassLoader")) {
                entry.put("type", "Context Manipulation");
                entry.put("description", "Changing thread context class loader");
                entry.put("sanitized_code", "Thread.currentThread().setContextClassLoader(secureClassLoader);");
                found = true;
            } else if (methodName.equals("getContextClassLoader")) {
                entry.put("type", "Context Fetching");
                entry.put("description", "Fetching thread context class loader");
                entry.put("sanitized_code", "Thread.currentThread().getContextClassLoader();");
                found = true;
            } else if (fullCall.contains("new File") && fullCall.contains(".class")) {
                entry.put("type", "Local Class Loading");
                entry.put("description", "Loading local .class files directly");
                entry.put("sanitized_code", "validateAndLoadClassFromFile()");
                found = true;
            } else if (fullCall.contains("getSystemResource")) {
                entry.put("type", "Resource Loading");
                entry.put("description", "System resource access may allow code injection");
                entry.put("sanitized_code", "getSystemResource(whitelistedName)");
                found = true;
            } else if (fullCall.contains("getSystemResources")) {
                entry.put("type", "Resource Enumeration");
                entry.put("description", "Resource scanning may break encapsulation");
                entry.put("sanitized_code", "enumerateOnlyTrustedResources()");
                found = true;
            } else if (methodName.equals("exec") || (methodName.equals("start") && fullCall.contains("ProcessBuilder"))) {
                entry.put("type", "Command Injection");
                entry.put("description", "Unfiltered use of Runtime.exec or ProcessBuilder");
                entry.put("sanitized_code", "validateCommand(cmd); Runtime.getRuntime().exec(cmd);");
                found = true;
            } else if ((fullCall.contains("new File") || fullCall.contains("FileInputStream")) && !fullCall.contains(".class")) {
                entry.put("type", "Path Traversal");
                entry.put("description", "File load path should be sanitized");
                entry.put("sanitized_code", "Validated path with baseDir check");
                found = true;
            } else if (methodName.equals("readObject") || methodName.equals("readUnshared")) {
                entry.put("type", "Unsafe Deserialization");
                entry.put("description", "Deserializing untrusted input");
                entry.put("sanitized_code", "Setup object input filters before read");
                found = true;
            } else if (fullCall.contains("DocumentBuilderFactory") || fullCall.contains("SAXParserFactory")) {
                entry.put("type", "XXE Vulnerability");
                entry.put("description", "XML Parsers should disable external entity resolution");
                entry.put("sanitized_code", "factory.setFeature(...disallow-doctype-decl...)");
                found = true;
            } else if (methodName.equals("invoke") || methodName.equals("setAccessible")) {
                entry.put("type", "Reflection Abuse");
                entry.put("description", "Unchecked reflective calls");
                entry.put("sanitized_code", "check before reflective method access");
                found = true;
            } else if (methodName.equals("nextInt") || methodName.equals("nextDouble")) {
                entry.put("type", "Insecure Randomness");
                entry.put("description", "Use of insecure pseudo-random generator");
                entry.put("sanitized_code", "Use SecureRandom instead of Random");
                found = true;
            } else if (methodName.equals("getProperty")) {
                entry.put("type", "Sensitive Property Access");
                entry.put("description", "Reading system properties may leak sensitive info");
                entry.put("sanitized_code", "Only allow whitelisted keys");
                found = true;
            } else if (methodName.equals("openConnection")) {
                entry.put("type", "Unrestricted Network Access");
                entry.put("description", "Dangerous URL openConnection without validation");
                entry.put("sanitized_code", "if (isSafeURL(url)) { url.openConnection(); }");
                found = true;
            }

            if (found) {
                if (instrumentationMode && line > 0 && line <= codeLines.size()) {
                    String original = codeLines.get(line - 1);
                    String injected = "SecurityLogger.log(\"" + entry.get("type")
                            + " at line " + line + "\");\n" + original;
                    sanitizedReplacements.put(line, injected);
                }
                findings.add(entry);
            }
        }
    }
}
