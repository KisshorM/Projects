
public class SecurityLogger {
    public static void log(String message) {
        System.out.println("[SECURITY LOG] " + message);
    }
}
