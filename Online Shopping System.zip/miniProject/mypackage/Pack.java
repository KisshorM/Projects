package mypackage;
import java.util.*;
import java.io.Serializable;

public abstract class Pack implements Serializable
{
  Product a;
  int quantity;

  public abstract double cal();
}





